package com.example.SpringBookProject.model;


import org.springframework.beans.factory.annotation.Autowired;

public class BookModel {
    @Autowired
    com.example.SpringBookProject.repository.BookRepository bookRepository;
}

