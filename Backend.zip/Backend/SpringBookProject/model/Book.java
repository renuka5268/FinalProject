package com.example.SpringBookProject.model;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Book {
    private String kind;
    private String id;
    private String tag;
    private String link;

    public Book(String kind, String id, String tag, String link) {
        this.kind = kind;
        this.id = id;
        this.tag = tag;
        this.link = link;
    }
}


